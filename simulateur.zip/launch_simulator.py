
from time import sleep

from simulator.FrameStream import FrameStreamAdapter

from simulator.proxy.OSCProxy import OSCProxy



def launchSimulation():

    stream = FrameStreamAdapter(deviceId="reak-hermes-5")
    proxy = OSCProxy("SENDER")
    stream.attachProxy(proxy)

    stream.setStatus("READY")


    electrodePackage = {
        "0":0,
        "1":1,
        "2":0,
        "3":1,
        "4":0,
        "5":1,
        "6":0,
        "7":1,
        "ref":0
    }

    stream.addMetricsKeyValue("electrodes", electrodePackage)

    stream.startStream()


    while(True):
        sleep(1)










if __name__ == "__main__":
    launchSimulation()